const body = document.body;
body.style.margin = '0';
body.style.display = 'flex';
body.style.justifyContent = 'center';
body.style.alignItems = 'center';
body.style.height = '100vh';
body.style.background = 'black';
body.style.fontFamily = 'Arial, sans-serif';

const container = document.createElement('div');
container.style.display = 'flex';
container.style.flexDirection = 'column';
container.style.alignItems = 'center';
container.style.justifyContent = 'center';
container.style.padding = '30px';
container.style.background = 'black';
container.style.width = '90vw';
container.style.maxWidth = '400px';
container.style.aspectRatio = '3 / 4';
container.style.border = "solid purple"
container.style.height = "120pt";
body.appendChild(container);

const h2 = document.querySelector('h2');
h2.style.color = 'white';
h2.style.fontSize = '1.8rem';
h2.style.marginBottom = '30px';
container.appendChild(h2)

const input = document.getElementById('numberInput');
input.style.padding = '10px';
input.style.fontSize = '1rem';
input.style.border = '1px solid #ccc';
input.style.borderRadius = '5px';
input.style.marginBottom = '10px';
input.style.width = '200px';
input.style.textAlign = 'center';
container.appendChild(input)

const button = document.getElementById('sendBtn');
button.style.padding = '10px 20px';
button.style.fontSize = '1rem';
button.style.border = 'none';
button.style.borderRadius = '5px';
button.style.backgroundColor = 'purple';
button.style.color = 'white';
button.style.cursor = 'pointer';
button.style.transition = 'background 0.3s';
button.style.width = '220px';
container.appendChild(button)

button.onmouseenter = () => button.style.backgroundColor = 'darkmagenta';
button.onmouseleave = () => button.style.backgroundColor = 'purple';

const result = document.getElementById('result');
result.style.marginTop = '20px';
result.style.fontSize = '1.2rem';
result.style.color = 'white';
container.appendChild(result)
